code_num = 0
waiting_time = 0
tryon_num = 0